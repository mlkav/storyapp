package com.rnlkav.storyapp

class Test {
    fun hello() = "world"
}
