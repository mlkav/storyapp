# Implementation Plan - Dicoding Story App

This plan outlines the steps to build a high-quality Story App for the Dicoding submission, following MVVM architecture and clean code principles.

## User Review Required

> [!IMPORTANT]
> I will be using **View Binding** as requested.
> For animations, I will implement **Property Animation** on the Login and Register screens to provide a smooth onboarding experience.
> I will use **DataStore Preferences** for session management.

## Proposed Changes

### 1. Project Configuration
Update dependencies and enable necessary features.

#### [MODIFY] [libs.versions.toml](file:///home/ald/AndroidStudioProjects/StoryApp/gradle/libs.versions.toml)
Add versions and library definitions for:
- Retrofit, OkHttp, Gson
- Lifecycle (ViewModel, LiveData)
- DataStore Preferences
- Glide (Image loading)
- Coroutines
- Activity & Fragment KTX

#### [MODIFY] [build.gradle.kts (app)](file:///home/ald/AndroidStudioProjects/StoryApp/app/build.gradle.kts)
- Enable `viewBinding`.
- Add the new dependencies.

---

### 2. Data Layer
Handle networking and local preferences.

#### [NEW] `data/api/`
- `ApiConfig.kt`: Retrofit setup with an interceptor for the Bearer token.
- `ApiService.kt`: Define endpoints for Register, Login, and Stories.

#### [NEW] `data/response/`
- Data classes for API responses (RegisterResponse, LoginResponse, StoryResponse, etc.).

#### [NEW] `data/pref/`
- `UserModel.kt`: Data class for user session (email, token, isLogin).
- `UserPreference.kt`: Manage DataStore for saving/loading `UserModel`.

#### [NEW] `data/repository/`
- `UserRepository.kt`: Main repository to handle Auth and Story operations.

---

### 3. Custom View
Implement specialized UI components.

#### [NEW] `ui/customview/MyEmailEditText.kt`
- Custom EditText with real-time email format validation.
- Custom EditText with real-time password validation (min 8 characters).

---

### 4. ViewModel & Factory
Infrastructure for MVVM.

#### [NEW] `ui/ViewModelFactory.kt`
- Factory to provide Repositories to ViewModels.

---

### 5. Authentication (Register & Login)
#### [NEW] `ui/register/`
- `RegisterActivity.kt`, `RegisterViewModel.kt`, `activity_register.xml`.
- Implementation of registration logic and property animations.

#### [NEW] `ui/login/`
- `LoginActivity.kt`, `LoginViewModel.kt`, `activity_login.xml`.
- Implementation of login logic, session saving, and property animations.

---

### 6. Main Flow (List & Detail)
#### [NEW] `ui/main/`
- `MainActivity.kt`, `MainViewModel.kt`, `activity_main.xml`.
- RecyclerView setup for stories.
- Logout functionality.
- Session check (redirect to Login if not authenticated).

#### [NEW] `ui/adapter/StoriesAdapter.kt`
- Adapter for the story list with ViewBinding.

#### [NEW] `ui/detail/`
- `DetailActivity.kt`, `activity_detail.xml`.
- Display story details.

---

### 7. Add Story
#### [NEW] `ui/add/`
- `AddStoryActivity.kt`, `AddStoryViewModel.kt`, `activity_add_story.xml`.
- Camera and Gallery integration.
- Image compression logic.
- Multipart upload.

---

### 8. Utils & Resources
#### [NEW] `utils/Utils.kt`
- Helper functions for Date formatting, Image Uri handling, and compression.

#### [MODIFY] `res/values/strings.xml` & `res/values-id/strings.xml`
- Localization for all UI text.

---

### 9. Finalization
#### [NEW] [student_notes.txt](file:///home/ald/AndroidStudioProjects/StoryApp/student_notes.txt)
- Document the animations used.

## Verification Plan

### Automated Tests
- Build the project to ensure no compilation errors.
- (Optional) Unit tests for Repository/ViewModel logic if time permits.

### Manual Verification
1. **Auth**: Register a new user, login, verify token is saved.
2. **Session**: Re-open app, verify it goes straight to MainActivity.
3. **List**: Verify stories are fetched and displayed correctly.
4. **Detail**: Click a story and verify details match.
5. **Add Story**:
    - Take a photo/select from gallery.
    - Upload with description.
    - Verify redirection to Main and new story appears at the top.
6. **Logout**: Click logout and verify redirection to LoginActivity.
7. **Localization**: Change device language to Indonesian and verify UI text changes.
8. **Animations**: Observe property animations on Login/Register.
